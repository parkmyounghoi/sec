﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp_classfile_separate
{
    class GameCharacterClass
    {
        public static int mCountOfMember = 0;
        public string mId;

        public GameCharacterClass()
        {
            mCountOfMember++;
        }
    }
}
