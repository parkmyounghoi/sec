﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp1
{
    public class LogClass
    {
        public static string log { get; set; }
        public static string log_date { get; set; }
    }
}
